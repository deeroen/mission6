/**
 * Classe de test pour la classe Chanson
 * 
 * @author Ch. Pecheur
 * @version Oct 2012
 */
public class TestChanson {

	public static void main(String[] args) {
		Chanson ch = new Chanson("Un_titre", "Un_auteur", new Temps(0,5,25));
		System.out.println(ch);
		
		// Ajouter des tests ici
	}

}
