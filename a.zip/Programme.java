
/**
 * Write a description of class Programme here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Programme
{
    public static void main () {
        TextIO.readFile("music-db.txt");
        Chanson[]tab=new Chanson[100];
        for (int i=0; !TextIO.eof();i++) { 
            String titre = TextIO.getWord();
            String auteur = TextIO.getWord() ;
            int min = TextIO.getInt();
            int sec = TextIO.getInt();
            int h = 0;
            
            Temps dureechanson = new Temps(h,min,sec);
            Chanson chanson = new Chanson (titre,auteur,dureechanson);
            TextIO.getln();
            System.out.println(chanson.toString()) ;
            tab[i]=chanson;
            
        }
    }
}
