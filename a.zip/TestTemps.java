/**
 * Classe de test pour la classe Temps
 * 
 * @author Ch. Pecheur
 * @version Oct 2012
 */
public class TestTemps {
	
	public static void main(String[] args) {
		Temps t = new Temps(12, 34, 56);
		System.out.println(t);
		
		// Ajouter des tests ici
	}

}
